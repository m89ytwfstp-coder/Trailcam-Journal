//
//  ImportView.swift
//  Trailcam Journal
//

import SwiftUI

struct ImportView: View {
    var body: some View {
        ImportWorkflowView()
    }
}
